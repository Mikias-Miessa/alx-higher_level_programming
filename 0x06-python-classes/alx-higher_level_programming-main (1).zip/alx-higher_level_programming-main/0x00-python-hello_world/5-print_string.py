#!/usr/bin/python3
str = "Holberton School"
print(str * 3)
print(str[:9])
