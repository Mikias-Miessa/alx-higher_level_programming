#!/usr/bin/python3
def add(a, b):
    """My addition function
      Args:

         a: first integer
         b: second integer

      Return:
        The return value. a+b
    """
    return(a+b)
