This is for python conditionals and loops
