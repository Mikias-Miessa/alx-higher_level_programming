#!/usr/bin/python3
for i in range(0, 100):
    if i == 89:
        print("{:02d}".format(i))
        continue
    check = str(i)[::-1]
    if int(check) > i:
            print("{:02d}".format(i), end=", ")
