#!/usr/bin/python3
def islower(c):
    asci = ord(c)
    if(asci >= 97 and asci < 123):
        return True
    return False
