#!/usr/bin/python3
"""json object"""


def class_to_json(obj):
    """dict obj"""
    return obj.__dict__
